angular.module('beamng.apps')
  .directive('tpToMarkApp', [function () {
    return {
      restrict: 'EA',
      replace: true,
      scope: true,
      templateUrl: '/ui/modules/apps/TPToMark/template.html',
      controller: ['$scope', function ($scope) {
        $scope.teleportToMark = function () {
          var lua = `(function()
            local function toVec3(v)
              if not v then return nil end
              local t = type(v)
              if t == "userdata" then return v end
              if t == "cdata" then
                local okX, x = pcall(function() return v.x end)
                local okY, y = pcall(function() return v.y end)
                local okZ, z = pcall(function() return v.z end)
                if okX and okY and okZ and x and y and z then
                  return vec3(x, y, z)
                end
                return nil
              end
              if t == "string" then
                local mapData = map and map.getMap and map.getMap()
                local node = mapData and mapData.nodes and mapData.nodes[v]
                return node and node.pos or nil
              end
              if t == "table" then
                if v.pos then return toVec3(v.pos) end
                if v.x and v.y and v.z then return vec3(v.x, v.y, v.z) end
                if #v >= 3 then return vec3(v[1], v[2], v[3]) end
              end
              return nil
            end

            local veh = be:getPlayerVehicle(0)
            if not veh then return "no_vehicle" end

            if not (core_groundMarkers and core_groundMarkers.getTargetPos) then
              return "no_marker_api"
            end

            local target = core_groundMarkers.getTargetPos()
            if not target and core_groundMarkers.endWP and core_groundMarkers.endWP[1] then
              target = core_groundMarkers.endWP[1]
            end
            if not target then return "no_target" end

            local targetPos = toVec3(target)
            if not targetPos then
              return "invalid_target_type:" .. tostring(type(target))
            end

            local ok, err = pcall(function()
              veh:setPosition(targetPos)
            end)
            if not ok then
              return "setpos_error:" .. tostring(err)
            end
            return "ok:" .. tostring(type(target))
          end)()`;

          bngApi.engineLua(lua, function (res) {
            if (typeof res === 'string' && res.indexOf('ok:') === 0) {
              var t = res.split(':')[1] || 'unknown';
              return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='success',title='TP To Mark',msg='Teleported (target type: " + t + ").',config={timeOut=2500,extendedTimeOut=800}})");
            }
            if (res === 'no_target') return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='warning',title='TP To Mark',msg='No active map marker selected.',config={timeOut=3000,extendedTimeOut=800}})");
            if (res === 'no_vehicle') return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='error',title='TP To Mark',msg='Player vehicle not found.',config={timeOut=3000,extendedTimeOut=800}})");
            var detail = (res || 'unknown').toString().replace(/'/g, '');
            return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='error',title='TP To Mark',msg='Teleport failed: " + detail + "',config={timeOut=4500,extendedTimeOut=1000}})");
          });
        };
      }]
    };
  }]);
