angular.module('beamng.apps')
  .directive('teleportApp', ['$interval', function ($interval) {
    return {
      restrict   : 'EA',
      replace    : true,
      scope      : true,
      templateUrl: '/ui/modules/apps/Teleport/template.html',
      controller : ['$scope', '$interval', function ($scope, $interval) {
        $scope.vehicles = [];
        $scope.Math    = window.Math;
        $scope.abs = {x:'',y:'',z:''};
        $scope.rel = {x:'',y:'',z:''};

        // 记录隐藏状态
        $scope.hiddenVehicles = new Set();

        function getPlayerPos(cb){
          bngApi.engineLua('be:getPlayerVehicle(0):getPosition()', function(pos){
            cb(pos || {x:0,y:0,z:0});
          });
        }

        $scope.teleportAbs = function(){
          getPlayerPos(function(pos){
            var x = $scope.abs.x !== '' ? Number($scope.abs.x) : pos.x;
            var y = $scope.abs.y !== '' ? Number($scope.abs.y) : pos.y;
            var z = $scope.abs.z !== '' ? Number($scope.abs.z) : pos.z;
            doTeleport(x,y,z);
          });
        };

        $scope.teleportRel = function(){
          getPlayerPos(function(pos){
            var dx = $scope.rel.x !== '' ? Number($scope.rel.x) : 0;
            var dy = $scope.rel.y !== '' ? Number($scope.rel.y) : 0;
            var dz = $scope.rel.z !== '' ? Number($scope.rel.z) : 0;
            doTeleport(pos.x + dx, pos.y + dy, pos.z + dz);
          });
        };

        $scope.teleportToMapMarker = function(){
          var lua = `(function()
            local function toVec3(v)
              if not v then return nil end
              local t = type(v)
              if t == "userdata" then return v end
              if t == "cdata" then
                local okX, x = pcall(function() return v.x end)
                local okY, y = pcall(function() return v.y end)
                local okZ, z = pcall(function() return v.z end)
                if okX and okY and okZ and x and y and z then
                  return vec3(x, y, z)
                end
                return nil
              end
              if t == "string" then
                local mapData = map and map.getMap and map.getMap()
                local node = mapData and mapData.nodes and mapData.nodes[v]
                return node and node.pos or nil
              end
              if t == "table" then
                if v.pos then return toVec3(v.pos) end
                if v.x and v.y and v.z then return vec3(v.x, v.y, v.z) end
                if #v >= 3 then return vec3(v[1], v[2], v[3]) end
              end
              return nil
            end

            local v = be:getPlayerVehicle(0)
            if not v then return "no_vehicle" end

            if not (core_groundMarkers and core_groundMarkers.getTargetPos) then
              return "no_marker_api"
            end

            local target = core_groundMarkers.getTargetPos()
            if not target and core_groundMarkers.endWP and core_groundMarkers.endWP[1] then
              target = core_groundMarkers.endWP[1]
            end
            if not target then return "no_target" end

            local targetPos = toVec3(target)
            if not targetPos then return "invalid_target_type:" .. tostring(type(target)) end
            local ok, err = pcall(function() v:setPosition(targetPos) end)
            if not ok then return "setpos_error:" .. tostring(err) end
            return "ok:" .. tostring(type(target))
          end)()`;

          bngApi.engineLua(lua, function(res){
            if(typeof res === 'string' && res.indexOf('ok:') === 0) {
              return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='success',title='TP DEBUG',msg='Marker TP ok.',config={timeOut=2500,extendedTimeOut=800}})");
            }
            var detail = (res || 'unknown').toString().replace(/'/g, '');
            return bngApi.engineLua("guihooks.trigger('toastrMsg',{type='error',title='TP DEBUG',msg='Marker TP fail: " + detail + "',config={timeOut=4500,extendedTimeOut=1000}})");
          });
        };

        $scope.teleportToVehicle = function(v){
          var lua = `(function()
            local tgt = be:getObjectByID(` + v.id + `)
            local ply = be:getPlayerVehicle(0)
            if not (tgt and ply) then return "error" end
            local p = tgt:getPosition()
            local o = tgt:getDirectionVector()
            local right = vec3(o.z, 0, -o.x):normalized()
            local dest = p + right * 2
            ply:setPosition(dest)
            return "ok"
          end)()`;
          bngApi.engineLua(lua, function(res){
            if(res !== 'ok') console.warn('[Teleport] 传送失败');
          });
        };

        // 隐藏/显示切换
        $scope.toggleVehicleVisibility = function(v) {
          var isHidden = $scope.hiddenVehicles.has(v.id);
          bngApi.engineLua(`be:getObjectByID(` + v.id + `):setHidden(` + !isHidden + `)`);
          if (isHidden) $scope.hiddenVehicles.delete(v.id);
          else          $scope.hiddenVehicles.add(v.id);
          $scope.$apply();
        };

        $scope.isVehicleHidden = function(v) {
          return $scope.hiddenVehicles.has(v.id);
        };

        function doTeleport(x,y,z){
          var lua = `(function()
            local v = be:getPlayerVehicle(0)
            if v then v:setPosition(vec3(`+x+','+y+','+z+`)) return "ok" end
          end)()`;
          bngApi.engineLua(lua, function(res){
            if(res !== 'ok') console.warn('[Teleport] 设置坐标失败');
          });
        }

        function fetchVehicles(){
          var lua = `(function()
            local t = {}
            for _,v in ipairs(getAllVehicles()) do
              if v ~= be:getPlayerVehicle(0) then
                local p = v:getPosition()
                local spd = v:getVelocity():length()
                t[#t+1] = {
                  id    = v:getID(),
                  x     = p.x,
                  y     = p.y,
                  z     = p.z,
                  speed = spd,
                  model = v:getJBeamFilename() or "unknown"
                }
              end
            end
            return jsonEncode(t)
          end)()`;
          bngApi.engineLua(lua, function(json){
            if(!json) return $scope.$apply(()=>$scope.vehicles=[]);
            try{ $scope.$apply(()=>$scope.vehicles=JSON.parse(json)); }catch(e){}
          });
        }

        fetchVehicles();
        var pollHandler = $interval(fetchVehicles, 200);
        $scope.$on('$destroy', ()=>$interval.cancel(pollHandler));
      }]
    };
  }]);